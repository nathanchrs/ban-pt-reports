from odoo import models, fields, api, exceptions


class Implementation_Int(models.Model):
	_name = 'itb.plan_implementation_int'
	_rec_name = 'plan_id'
	
	quarter = fields.Selection([('q1','Jan-Mar'),('q2', 'Apr-Jun'),('q3','Jul-Sep'),('q4','Oct-Dec')], 'Quarter',default='q1')
	reference = fields.Char()
	state = fields.Selection([('draft','Draft'),('confirm','Confirmed'),('validate','Validated')], 'Status', default='draft')
	plan_id = fields.Many2one('itb.plan_int',ondelete='cascade',required=True,index=True,domain="[('state','=','validate')]")
	spending_actual_ids = fields.One2many('itb.plan_spending_actual_int', 'implementation_id', 'Spending Implementation Lines', copy=True)
	
	def action_budget_state_confirmed(self):
		self.write({ 'state' : 'confirm' })
		return True

	def action_budget_state_validated(self):
		self.write({ 'state' : 'validate' })
		return True

	def action_budget_state_abort(self):
		self.write({ 'state' : 'draft' })
		return True


	@api.onchange('plan_id')
	def load_spending_items(self):
		spendings = self.env['itb.plan_spending_int'].search([('plan_id','=',self.plan_id)])
		implementation_lines = []
		
		for s in spendings:
			implementation_lines.append((0,0,{'name':s.name,'plan_line_id':s.plan_line_id,'type':s.type,'source':s.source,'month':s.month,'price':s.price}))

 		val = {'spending_actual_ids':implementation_lines}
		#self.spending_actual_ids = implementation_lines
		return {'value':val}
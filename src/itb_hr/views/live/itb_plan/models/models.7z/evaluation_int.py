from odoo import models, fields, api, exceptions


class Evaluation_Int(models.Model):
	_name = 'itb.plan_evaluation_int'
	_rec_name = 'plan_id'
	
	percent_performance = fields.Float()
	state = fields.Selection([('draft','Draft'),('confirm','Confirmed'),('validate','Validated')], 'Status', default='draft')
	plan_id = fields.Many2one('itb.plan_int',ondelete='cascade',required=True,index=True,domain="[('state','=','validate')]")
	evaluation_line_ids = fields.One2many('itb.plan_evaluation_line_int', 'evaluation_id', 'Plan Evaluation Lines', copy=True)
	
	
class Evaluation_Line_Int(models.Model):
	_name = 'itb.plan_evaluation_line_int'
	
	initiative = fields.Char(related='target_id.plan_line_id.name')
	plan = fields.Float(related='target_id.plan')
	actual = fields.Float()
	note = fields.Text()
	target_id = fields.Many2one('itb.plan_target_int',ondelete='cascade',required=True,index=True)
	evaluation_id = fields.Many2one('itb.plan_evaluation_int',ondelete='cascade',required=True,index=True)

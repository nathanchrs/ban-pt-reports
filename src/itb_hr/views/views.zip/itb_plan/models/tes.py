from odoo import models, fields, api, exceptions


class Tes(models.Model):


    _name = 'itb.plan_tes'

rec1 = fields.Integer()
rec2 = fields.Char()
